export type UserInfo = {
    familyName: string
    email: string
}

export const vincentInfo: UserInfo = {
    familyName: 'Wong',
    email: 'vincent.w.y.h@gmail.com',
}